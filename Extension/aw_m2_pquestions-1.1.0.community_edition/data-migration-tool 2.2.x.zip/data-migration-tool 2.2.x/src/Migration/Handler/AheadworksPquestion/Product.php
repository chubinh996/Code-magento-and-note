<?php
namespace Migration\Handler\AheadworksPquestion;

use Aheadworks\Pquestion\Model\Source\Question\Sharing\Type as SharingType;
use Aheadworks\Pquestion\Model\Source\Question\Status;
use Migration\ResourceModel\Source;
use Migration\ResourceModel\Destination;
use Migration\ResourceModel\Record;
use Migration\Handler\AbstractHandler;
use Migration\Handler\HandlerInterface;
use Migration\Logger\Logger;

/**
 * Handler for Sharing
 */
class Product extends AbstractHandler implements HandlerInterface
{
    const PRODUCTS_VALUE      = 1;
    const ATTRIBUTE_SET_VALUE = 2;
    const WEBSITE_VALUE       = 3;
    const GLOBAL_VALUE        = 4;

    /**
     * @var Source
     */
    private $source;

    /**
     * @var Destination
     */
    private $destination;

    /**
     * @var Logger
     */
    private $logger;

    /**
     * @param Source $source
     * @param Destination $destination
     * @param Logger $logger
     */
    public function __construct(
        Source $source,
        Destination $destination,
        Logger $logger
    ) {
        $this->source = $source;
        $this->destination = $destination;
        $this->logger = $logger;
    }

    /**
     * {@inheritdoc}
     */
    public function handle(Record $recordToHandle, Record $oppositeRecord)
    {
        $this->validate($recordToHandle);

        $sharingType = $recordToHandle->getValue($this->field);

        switch ($sharingType) {
            case self::PRODUCTS_VALUE:
                $this->convertProductsSharing($recordToHandle);
                break;
            case self::ATTRIBUTE_SET_VALUE:
                $this->convertAttributeSetSharing($recordToHandle);
                break;
            case self::WEBSITE_VALUE:
            case self::GLOBAL_VALUE:
                $this->convertGlobalSharing($recordToHandle);
                break;
        }

        $this->convertParentProduct($recordToHandle);
    }

    /**
     * Convert products sharing
     *
     * @param Record $recordToHandle
     * @throws \Migration\Exception
     */
    private function convertProductsSharing(Record $recordToHandle)
    {
        $sourceProductIds = explode(',', $recordToHandle->getValue('sharing_value'));
        $sourceProductSkus = $this->getSourceProductSkus($sourceProductIds);
        $destProductIds = $this->getDestProductIds($sourceProductSkus);
        if (count($destProductIds) == 1) {
            $recordToHandle->setValue($this->field, SharingType::ORIGINAL_PRODUCT_VALUE);
            $recordToHandle->setValue('sharing_value',  serialize([reset($destProductIds)]));
        } else if (count($destProductIds) > 0) {
            $recordToHandle->setValue($this->field, SharingType::SPECIFIED_PRODUCTS_VALUE);
            $recordToHandle->setValue('sharing_value',  serialize([
                'conditions' => [
                    '1' => [
                        'type' => \Magento\CatalogWidget\Model\Rule\Condition\Combine::class,
                        'aggregator' => 'all',
                        'value' => '1',
                        'new_child' => ''
                    ],
                    '1--1' => [
                        'type' => \Magento\CatalogWidget\Model\Rule\Condition\Product::class,
                        'attribute' => 'sku',
                        'operator' => '()',
                        'value' => implode(', ', $sourceProductSkus)
                    ]
                ]
            ]));
        } else {
            $this->logger->info(
                __(
                    'Question #%1 (%2): products for the sharing option not found',
                    [$recordToHandle->getValue('entity_id'), $recordToHandle->getValue('content')]
                )
            );
            $recordToHandle->setValue($this->field, SharingType::ALL_PRODUCTS_VALUE);
            $recordToHandle->setValue('sharing_value',  serialize([]));
            $recordToHandle->setValue('status', Status::PENDING_VALUE);
        }
    }

    /**
     * Convert attribute set sharing
     *
     * @param Record $recordToHandle
     * @throws \Migration\Exception
     */
    private function convertAttributeSetSharing(Record $recordToHandle)
    {
        $attributeSetFound = false;
        $sourceAttributeSetId = $recordToHandle->getValue('sharing_value');
        $sourceAttributeSetName = $this->getSourceAttributeSetName($sourceAttributeSetId);


        if ($sourceAttributeSetName) {
            $destAttributeSetId = $this->getDestAttributeSetId($sourceAttributeSetName);

            if ($destAttributeSetId) {
                $attributeSetFound = true;
                $recordToHandle->setValue($this->field, SharingType::SPECIFIED_PRODUCTS_VALUE);
                $recordToHandle->setValue('sharing_value',  serialize([
                    'conditions' => [
                        '1' => [
                            'type' => \Magento\CatalogWidget\Model\Rule\Condition\Combine::class,
                            'aggregator' => 'all',
                            'value' => '1',
                            'new_child' => ''
                        ],
                        '1--1' => [
                            'type' => \Magento\CatalogWidget\Model\Rule\Condition\Product::class,
                            'attribute' => 'attribute_set_id',
                            'operator' => '==',
                            'value' => $destAttributeSetId
                        ]
                    ]
                ]));
            }
        }

        if (!$attributeSetFound) {
            $this->logger->info(
                __(
                    'Question #%1 (%2): attribute set not found',
                    [$recordToHandle->getValue('entity_id'), $recordToHandle->getValue('content')]
                )
            );
            $recordToHandle->setValue($this->field, SharingType::ALL_PRODUCTS_VALUE);
            $recordToHandle->setValue('sharing_value',  serialize([]));
            $recordToHandle->setValue('status', Status::PENDING_VALUE);
        }
    }

    /**
     * Convert global sharing
     *
     * @param Record $recordToHandle
     * @throws \Migration\Exception
     */
    private function convertGlobalSharing(Record $recordToHandle)
    {
        $productFound = false;
        $sourceProductSku = $this->getSourceProductSku($recordToHandle->getValue('product_id'));

        if ($sourceProductSku) {
            $destProductId = $this->getDestProductId($sourceProductSku);

            if ($destProductId) {
                $productFound = true;
                $recordToHandle->setValue($this->field, SharingType::ALL_PRODUCTS_VALUE);
                $recordToHandle->setValue('sharing_value',  serialize([$destProductId]));
            }
        }

        if (!$productFound) {
            $this->logger->info(
                __(
                    'Question #%1 (%2): products for the sharing option not found',
                    [$recordToHandle->getValue('entity_id'), $recordToHandle->getValue('content')]
                )
            );
            $recordToHandle->setValue($this->field, SharingType::ALL_PRODUCTS_VALUE);
            $recordToHandle->setValue('sharing_value',  serialize([]));
            $recordToHandle->setValue('status', Status::PENDING_VALUE);
        }
    }

    /**
     * Convert parent product id
     *
     * @param Record $recordToHandle
     * @throws \Migration\Exception
     */
    private function convertParentProduct(Record $recordToHandle)
    {
        $productFound = false;
        $sourceProductSku = $this->getSourceProductSku($recordToHandle->getValue('product_id'));

        if ($sourceProductSku) {
            $destProductId = $this->getDestProductId($sourceProductSku);

            if ($destProductId) {
                $productFound = true;
                $recordToHandle->setValue('product_id', $destProductId);
            }
        }

        if (!$productFound) {
            $this->logger->info(
                __(
                    'Question #%1 (%2): the source product not found',
                    [$recordToHandle->getValue('entity_id'), $recordToHandle->getValue('content')]
                )
            );
            $recordToHandle->setValue('product_id', 0);
        }
    }

    /**
     * Get source attribute set name
     *
     * @param int $attributeSetId
     * @return string
     */
    private function getSourceAttributeSetName($attributeSetId)
    {
        $adapter = $this->source->getAdapter();
        $query = $adapter->getSelect()
            ->from(
                ['main_table' => $this->source->addDocumentPrefix('eav_attribute_set')],
                ['attribute_set_name']
            )
            ->where("attribute_set_id = ?", $attributeSetId);

        $result = $query->getAdapter()->fetchRow($query);
        if ($result) {
            return $result['attribute_set_name'];
        }

        return false;
    }

    /**
     * Get destination attribute set id
     *
     * @param string $attributeSetName
     * @return int
     */
    private function getDestAttributeSetId($attributeSetName)
    {
        $adapter = $this->destination->getAdapter();
        $query = $adapter->getSelect()
            ->from(
                ['main_table' => $this->destination->addDocumentPrefix('eav_attribute_set')],
                ['attribute_set_id']
            )
            ->joinInner(
                ['et' => $this->destination->addDocumentPrefix('eav_entity_type')],
                "main_table.entity_type_id = et.entity_type_id AND et.entity_type_code='catalog_product'",
                []
            )
            ->where("attribute_set_name = ?", $attributeSetName);

        $result = $query->getAdapter()->fetchRow($query);
        if ($result) {
            return $result['attribute_set_id'];
        }

        return false;
    }

    /**
     * Get source product sku
     *
     * @param int $productId
     * @return string|false
     */
    private function getSourceProductSku($productId)
    {
        $adapter = $this->source->getAdapter();
        $query = $adapter->getSelect()
            ->from(
                $this->source->addDocumentPrefix('catalog_product_entity'),
                ['sku']
            )
            ->where("entity_id = ?", $productId)
            ->order('updated_at desc');

        $result = $query->getAdapter()->fetchRow($query);
        if ($result) {
            return $result['sku'];
        }

        return false;
    }

    /**
     * Get source product skus
     *
     * @param int[] $productIds
     * @return string[]
     */
    private function getSourceProductSkus($productIds)
    {
        $skus = [];

        foreach ($productIds as $productId) {
            $sku = $this->getSourceProductSku($productId);
            if ($sku) {
                $skus[] = $sku;
            }
        }

        return $skus;
    }

    /**
     * Get destination product id
     *
     * @param string $sku
     * @return int|false
     */
    private function getDestProductId($sku)
    {
        $adapter = $this->destination->getAdapter();
        $query = $adapter->getSelect()
            ->from(
                $this->source->addDocumentPrefix('catalog_product_entity'),
                ['entity_id']
            )
            ->where("sku = ?", $sku)
            ->order('updated_at desc');

        $result = $query->getAdapter()->fetchRow($query);
        if ($result) {
            return $result['entity_id'];
        }

        return false;
    }

    /**
     * Get destination product ids
     *
     * @param string[] $skus
     * @return int[]
     */
    private function getDestProductIds($skus)
    {
        $ids = [];

        foreach ($skus as $sku) {
            $id = $this->getDestProductId($sku);
            if ($id) {
                $ids[] = $id;
            }
        }

        return $ids;
    }
}
