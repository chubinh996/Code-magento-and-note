<?php
namespace Migration\Handler\AheadworksPquestion;

use Migration\ResourceModel\Source;
use Migration\ResourceModel\Destination;
use Migration\ResourceModel\Record;
use Migration\Handler\AbstractHandler;
use Migration\Handler\HandlerInterface;

/**
 * Handler for Customer
 */
class Customer extends AbstractHandler implements HandlerInterface
{
    /**
     * @var Source
     */
    private $source;


    /**
     * @var Destination
     */
    private $destination;

    /**
     * @param Source $source
     * @param Destination $destination
     */
    public function __construct(
        Source $source,
        Destination $destination
    ) {
        $this->source = $source;
        $this->destination = $destination;
    }

    /**
     * {@inheritdoc}
     */
    public function handle(Record $recordToHandle, Record $oppositeRecord)
    {
        $this->validate($recordToHandle);
        $customerId = $recordToHandle->getValue($this->field);
        if ($customerId && $customerId > 0) {
            $adapter = $this->source->getAdapter();
            $query = $adapter->getSelect()
                ->from($this->source->addDocumentPrefix('customer_entity'), ['email', 'store_id'])
                ->where("entity_id = ?", $customerId)
            ;
            $result = $query->getAdapter()->fetchRow($query);
            $customerEmail = $result['email'];
            $customerStoreId = $result['store_id'];

            $destCustomerId = $this->getDestCustomerId($customerEmail, $customerStoreId);
            $recordToHandle->setValue($this->field, $destCustomerId);
        } else {
            $recordToHandle->setValue($this->field, 0);
        }
    }

    /**
     * Get destination customer id
     *
     * @param string $customerEmail
     * @param int $customerStoreId
     * @return int
     */
    private function getDestCustomerId($customerEmail, $customerStoreId)
    {
        $adapter = $this->destination->getAdapter();
        $query = $adapter->getSelect()
            ->from($this->destination->addDocumentPrefix('customer_entity'), ['entity_id', 'store_id'])
            ->where("email = ?", $customerEmail);

        $result = $query->getAdapter()->fetchAll($query);
        $customerId = 0;
        if ($result) {
            foreach ($result as $customer) {
                if (is_array($customer)
                    && isset($customer['store_id'])
                    && $customer['store_id'] == $customerStoreId
                ) {
                    $customerId = $customer['entity_id'];
                }
            }
            if ($customerId == 0) {
                $customer = reset($result);
                if (is_array($customer) && isset($customer['entity_id']))
                $customerId = $customer['entity_id'];
            }
        }

        return $customerId;
    }
}
