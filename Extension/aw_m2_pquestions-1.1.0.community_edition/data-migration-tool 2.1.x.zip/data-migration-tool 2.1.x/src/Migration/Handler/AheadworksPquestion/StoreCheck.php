<?php
namespace Migration\Handler\AheadworksPquestion;

use Migration\ResourceModel\Destination;
use Migration\ResourceModel\Record;
use Migration\Handler\AbstractHandler;
use Migration\Handler\HandlerInterface;
use Migration\Logger\Logger;

/**
 * Handler for StoreCheck
 */
class StoreCheck extends AbstractHandler implements HandlerInterface
{
    /**
     * @var Destination
     */
    private $destination;

    /**
     * @var Logger
     */
    private $logger;

    /**
     * @param Destination $destination
     * @param Logger $logger
     */
    public function __construct(
        Destination $destination,
        Logger $logger
    ) {
        $this->destination = $destination;
        $this->logger = $logger;
    }

    /**
     * {@inheritdoc}
     */
    public function handle(Record $recordToHandle, Record $oppositeRecord)
    {
        $sourceStoreId = $recordToHandle->getValue('store_id');

        if (!$this->ifDestStoreIdExists($sourceStoreId)) {
            $this->logger->info(
                __(
                    'Question #%1 (%2): store not found, skipped',
                    [$recordToHandle->getValue('entity_id'), $recordToHandle->getValue('content')]
                )
            );
            return false;
        }
        return true;
    }

    /**
     * Check if destination store exists
     *
     * @param int $storeId
     * @return bool
     */
    private function ifDestStoreIdExists($storeId)
    {
        $adapter = $this->destination->getAdapter();
        $query = $adapter->getSelect()
            ->from($this->destination->addDocumentPrefix('store'), ['store_id', 'name'])
            ->where("store_id = ?", $storeId);

        $result = $query->getAdapter()->fetchRow($query);
        if ($result) {
            return true;
        }
        return false;
    }
}
