<?php
namespace Migration\Handler\AheadworksPquestion;

use Migration\ResourceModel\Record;
use Migration\Handler\HandlerInterface;

/**
 * Handler for NotificationCheck
 */
class NotificationCheck extends Notification implements HandlerInterface
{
    /**
     * {@inheritdoc}
     */
    public function handle(Record $recordToHandle, Record $oppositeRecord)
    {
        $sourceNotification = $recordToHandle->getValue('notification_type');
        if (!array_key_exists($sourceNotification, self::NOTIFICATION_TYPE_MAP)) {
            return false;
        }
        return true;
    }
}
