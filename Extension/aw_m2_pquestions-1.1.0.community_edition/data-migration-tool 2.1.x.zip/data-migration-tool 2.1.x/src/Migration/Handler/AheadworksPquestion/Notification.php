<?php
namespace Migration\Handler\AheadworksPquestion;

use Aheadworks\Pquestion\Model\Source\Notification\Type as NotificationType;
use Migration\ResourceModel\Record;
use Migration\Handler\AbstractHandler;
use Migration\Handler\HandlerInterface;

/**
 * Handler for Notification
 */
class Notification extends AbstractHandler implements HandlerInterface
{
    /**
     * Notification type map
     */
    const NOTIFICATION_TYPE_MAP = [
        'aw_pq2_question_status_change_to_customer' => NotificationType::QUESTION_STATUS_CHANGE_TO_CUSTOMER,
        'aw_pq2_question_auto_responder' => NotificationType::QUESTION_AUTO_RESPONDER,
        'aw_pq2_new_reply_on_question_to_customer' => NotificationType::NEW_REPLY_ON_QUESTION_TO_CUSTOMER,
        'aw_pq2_answer_status_change_to_customer' => NotificationType::ANSWER_STATUS_CHANGE_TO_CUSTOMER,
        'aw_pq2_answer_auto_responder' => NotificationType::ANSWER_AUTO_RESPONDER
    ];

    const NOT_SUPPORTED = 'not_supported';

    /**
     * {@inheritdoc}
     */
    public function handle(Record $recordToHandle, Record $oppositeRecord)
    {
        $this->validate($recordToHandle);
        $srcValue = $recordToHandle->getValue($this->field);

        $destValue = self::NOT_SUPPORTED;
        if (isset(self::NOTIFICATION_TYPE_MAP[$srcValue])) {
            $destValue = self::NOTIFICATION_TYPE_MAP[$srcValue];
        }

        $recordToHandle->setValue($this->field, $destValue);
    }
}
