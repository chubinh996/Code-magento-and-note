<?php
/*
 *
 */
namespace FishPig\WordPress_PluginShortcodeWidget\Block;

/* Parent Class */
use Magento\Catalog\Block\Product\AbstractProduct;

class ProductShortcode extends AbstractProduct
{
}
