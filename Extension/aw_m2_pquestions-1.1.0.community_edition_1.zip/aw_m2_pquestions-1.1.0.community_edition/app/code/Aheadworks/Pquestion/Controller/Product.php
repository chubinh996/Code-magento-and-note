<?php
/**
* Copyright 2016 aheadWorks. All rights reserved.
* See LICENSE.txt for license details.
*/

namespace Aheadworks\Pquestion\Controller;

abstract class Product extends \Magento\Framework\App\Action\Action
{

}
