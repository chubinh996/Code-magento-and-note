/**
* Copyright 2016 aheadWorks. All rights reserved.
* See LICENSE.txt for license details.
*/

var config = {
    map: {
        '*': {
            AWPquestion: 'Aheadworks_Pquestion/js/aw_pquestion',
            AWPquestionPopup: 'Aheadworks_Pquestion/js/aw_pquestion_popup',
            AWPquestionSorter: 'Aheadworks_Pquestion/js/aw_pquestion_sorter',
            AWPquestionVoter: 'Aheadworks_Pquestion/js/aw_pquestion_voter'
        }
    }
};